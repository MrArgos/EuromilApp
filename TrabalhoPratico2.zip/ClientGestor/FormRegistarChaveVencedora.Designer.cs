﻿
namespace ClientGestor
{
    partial class FormRegistarChaveVencedora
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBoxNumero1 = new System.Windows.Forms.TextBox();
            this.textBoxNumero2 = new System.Windows.Forms.TextBox();
            this.textBoxNumero3 = new System.Windows.Forms.TextBox();
            this.textBoxNumero4 = new System.Windows.Forms.TextBox();
            this.textBoxNumero5 = new System.Windows.Forms.TextBox();
            this.textBoxEstrela1 = new System.Windows.Forms.TextBox();
            this.textBoxEstrela2 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.buttonRegistar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // textBoxNumero1
            // 
            this.textBoxNumero1.Location = new System.Drawing.Point(28, 45);
            this.textBoxNumero1.Name = "textBoxNumero1";
            this.textBoxNumero1.Size = new System.Drawing.Size(24, 23);
            this.textBoxNumero1.TabIndex = 0;
            // 
            // textBoxNumero2
            // 
            this.textBoxNumero2.Location = new System.Drawing.Point(58, 45);
            this.textBoxNumero2.Name = "textBoxNumero2";
            this.textBoxNumero2.Size = new System.Drawing.Size(24, 23);
            this.textBoxNumero2.TabIndex = 1;
            // 
            // textBoxNumero3
            // 
            this.textBoxNumero3.Location = new System.Drawing.Point(88, 45);
            this.textBoxNumero3.Name = "textBoxNumero3";
            this.textBoxNumero3.Size = new System.Drawing.Size(24, 23);
            this.textBoxNumero3.TabIndex = 2;
            // 
            // textBoxNumero4
            // 
            this.textBoxNumero4.Location = new System.Drawing.Point(118, 45);
            this.textBoxNumero4.Name = "textBoxNumero4";
            this.textBoxNumero4.Size = new System.Drawing.Size(24, 23);
            this.textBoxNumero4.TabIndex = 3;
            // 
            // textBoxNumero5
            // 
            this.textBoxNumero5.Location = new System.Drawing.Point(148, 45);
            this.textBoxNumero5.Name = "textBoxNumero5";
            this.textBoxNumero5.Size = new System.Drawing.Size(24, 23);
            this.textBoxNumero5.TabIndex = 4;
            // 
            // textBoxEstrela1
            // 
            this.textBoxEstrela1.Location = new System.Drawing.Point(199, 45);
            this.textBoxEstrela1.Name = "textBoxEstrela1";
            this.textBoxEstrela1.Size = new System.Drawing.Size(24, 23);
            this.textBoxEstrela1.TabIndex = 5;
            // 
            // textBoxEstrela2
            // 
            this.textBoxEstrela2.Location = new System.Drawing.Point(229, 45);
            this.textBoxEstrela2.Name = "textBoxEstrela2";
            this.textBoxEstrela2.Size = new System.Drawing.Size(24, 23);
            this.textBoxEstrela2.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(178, 48);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(15, 15);
            this.label1.TabIndex = 7;
            this.label1.Text = "+";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(28, 27);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 15);
            this.label2.TabIndex = 8;
            this.label2.Text = "Números";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(199, 27);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(46, 15);
            this.label3.TabIndex = 9;
            this.label3.Text = "Estrelas";
            // 
            // buttonRegistar
            // 
            this.buttonRegistar.Location = new System.Drawing.Point(28, 86);
            this.buttonRegistar.Name = "buttonRegistar";
            this.buttonRegistar.Size = new System.Drawing.Size(225, 23);
            this.buttonRegistar.TabIndex = 10;
            this.buttonRegistar.Text = "Registar Chave Vencedora";
            this.buttonRegistar.UseVisualStyleBackColor = true;
            this.buttonRegistar.Click += new System.EventHandler(this.buttonRegistar_Click);
            // 
            // FormRegistarChaveVencedora
            // 
            this.AcceptButton = this.buttonRegistar;
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(286, 136);
            this.Controls.Add(this.buttonRegistar);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBoxEstrela2);
            this.Controls.Add(this.textBoxEstrela1);
            this.Controls.Add(this.textBoxNumero5);
            this.Controls.Add(this.textBoxNumero4);
            this.Controls.Add(this.textBoxNumero3);
            this.Controls.Add(this.textBoxNumero2);
            this.Controls.Add(this.textBoxNumero1);
            this.Name = "FormRegistarChaveVencedora";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Registar Chave Vencedora";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBoxNumero1;
        private System.Windows.Forms.TextBox textBoxNumero2;
        private System.Windows.Forms.TextBox textBoxNumero3;
        private System.Windows.Forms.TextBox textBoxNumero4;
        private System.Windows.Forms.TextBox textBoxNumero5;
        private System.Windows.Forms.TextBox textBoxEstrela1;
        private System.Windows.Forms.TextBox textBoxEstrela2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button buttonRegistar;
    }
}