﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace ServidorApostas.Migrations
{
    public partial class SecondSave : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
